@echo off
powershell .\pingmonitor.ps1